/**
 * Proforma & customer advances (MOD-50, KB §7/§8.1). A proforma is NOT revenue;
 * a payment on it is a LIABILITY (customer advance, 4191): Dr <treasury> / Cr 4191,
 * cleared later by the final invoice. All SQL is in proforma.repo.
 */
"use strict";

const repo = require("./proforma.repo");
const events = require("./proforma.events");
const journalEntry = require("../journal_entry/journal_entry.service");
const { emitEvent, audit } = require("../../../shared/events/emit");
const numbering = require("../../../services/documents/numbering.service");
const documents = require("../../../services/documents/document.service");
const { AppError } = require("../../../utils/errors");
const { accountFor } = require("../../../shared/config/finance-accounts");

async function recordPayment(client, opts) {
  const {
    entityId, clientId = null, dossierId = null, amount,
    treasuryCoa = null, advanceAccount = null,
    entryDate, sourceDocRef, actor = {}, ip = null,
  } = opts;
  if (!(Number(amount) > 0)) throw new AppError("BAD_AMOUNT", "amount must be > 0", 422);

  // "521" is a non-postable grouping (9000:77) — the ledger trigger refused it,
  // so a proforma payment failed unless the caller named an account. Both now
  // come from ('finance','accounts'); an explicit override still wins.
  const treasury = await accountFor(client, "treasury", treasuryCoa);
  const advance = await accountFor(client, "customer_advance", advanceAccount);

  await client.query("BEGIN");
  try {
    const { entry } = await journalEntry.buildAndInsert(client, {
      journalCode: "BQ", entityId, entryDate,
      description: "Customer advance received (proforma)", sourceDocRef, source: "SYSTEM_RULE",
      lines: [
        { account_code: treasury, debit: amount, credit: 0, dossier_id: dossierId },
        { account_code: advance, debit: 0, credit: amount, dossier_id: dossierId },
      ],
      validate: true, actor, ip,
    });
    const advance = await repo.insertAdvance(client, { client_id: clientId, dossier_id: dossierId, amount, entry_id: entry.entry_id });
    const { number } = await numbering.allocate(client, { moduleKey: events.MODULE, entityId, date: entryDate });
    await documents.capture(client, { entityRef: "advance:" + advance.advance_id, docType: "PROFORMA_ADVANCE", status: "VERIFIED" });
    advance.doc_number = number;
    await emitEvent(client, { eventTypeKey: events.PAID, moduleKey: events.MODULE, entityRef: "advance:" + advance.advance_id, actorUserId: actor.user_id || null });
    await audit(client, { actorUserId: actor.user_id || null, action: events.PAID, moduleKey: events.MODULE, entityRef: "advance:" + advance.advance_id, after: advance, ip });
    await client.query("COMMIT");
    return { entry, advance };
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  }
}

const get = (client, id) => repo.getAdvance(client, id);
/** One page of advances plus the filter total, for `X-Total-Count`. */
const listPaged = (client, q) => repo.listAdvances(client, q);

/** Bare array — kept for non-HTTP callers that expect a list, not an envelope. */
const list = async (client, q) => (await repo.listAdvances(client, q)).rows;

module.exports = { recordPayment, get, list, listPaged };
