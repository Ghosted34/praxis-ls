/**
 * Support & Feedback (tenant side, PRD §11.2) — the tenant→Praxis channel. Users
 * raise support / bug / feature tickets and watch their lifecycle
 * (NEW → TRIAGED → IN_PROGRESS → SHIPPED/DECLINED); Praxis triages them on the
 * Platform Console. CSAT can be given once a ticket is resolved. Backed by the
 * ungated tenant API `/support/tickets` (writes the central platform ticket
 * store, scoped to this tenant).
 */
import { pageShell } from "@/lib/layout";
import { tr } from "@/lib/i18n";
import * as React from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Modal, Field, Select } from "@/components/ui/modal";
import { ErrorState } from "@/components/ui/states";
import { PageHeader, DataList, type Column } from "@/components/data-list";
import { KpiRow, KpiTile } from "@/components/ui/kpi-tile";
import { Pill, type Tone } from "@/components/ui/pill";
import { RowActions } from "@/components/ui/row-actions";
import { useList, errMsg } from "@/lib/use-resource";
import { num, dateFmt } from "@/lib/format";
import { tenant } from "@/lib/api-client";

type Kind = "SUPPORT" | "BUG" | "FEATURE";
type Status = "NEW" | "TRIAGED" | "IN_PROGRESS" | "SHIPPED" | "DECLINED";

type Ticket = {
  ticket_id: string;
  kind: Kind;
  title: string;
  body?: string | null;
  status: Status;
  csat?: number | null;
  created_at?: string | null;
};

const KIND_LABEL: Record<Kind, string> = {
  SUPPORT: "Support",
  BUG: "Bug",
  FEATURE: "Feature",
};

/**
 * G8 — snapshot the current app context onto a support ticket. Every part is
 * independently guarded and never throws: triage gets what is available and
 * a missing piece must not sink the ticket. Includes the last client error
 * the global error-reporting captured (route + message + stack), the page the
 * user was on, and static browser facts.
 */
function buildTicketContext(): Record<string, unknown> {
  const ctx: Record<string, unknown> = {
    captured_at: new Date().toISOString(),
    route: typeof window !== "undefined" ? window.location.pathname : null,
    user_agent: typeof navigator !== "undefined" ? navigator.userAgent : null,
  };
  try {
    const last = (window as unknown as { __praxisLastClientError?: { message: string; route?: string; stack?: string; kind?: string; at?: string } }).__praxisLastClientError;
    if (last) {
      ctx.last_error = {
        message: String(last.message || "").slice(0, 500),
        route: last.route || null,
        kind: last.kind || "render",
        at: last.at || null,
        stack: last.stack ? String(last.stack).slice(0, 2000) : null,
      };
    }
  } catch {
    /* context capture is best-effort */
  }
  return ctx;
}
const KIND_TONE: Record<Kind, Tone> = {
  SUPPORT: "blue",
  BUG: "bad",
  FEATURE: "orange",
};
const STATUS_LABEL: Record<Status, string> = {
  NEW: "New",
  TRIAGED: "Triaged",
  IN_PROGRESS: "In progress",
  SHIPPED: "Shipped",
  DECLINED: "Declined",
};
const STATUS_TONE: Record<Status, Tone> = {
  NEW: "warn",
  TRIAGED: "blue",
  IN_PROGRESS: "blue",
  SHIPPED: "ok",
  DECLINED: "bad",
};
const isResolved = (s: Status) => s === "SHIPPED" || s === "DECLINED";

function NewTicketModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: () => void;
}) {
  const [kind, setKind] = React.useState<Kind>("SUPPORT");
  const [title, setTitle] = React.useState("");
  const [body, setBody] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await tenant("/support/tickets", {
        method: "POST",
        body: {
          kind,
          title: title.trim(),
          body: body.trim(),
          // G8 — the Pixie Girl model (meeting §11.16): "Need help? Send this
          // to your system admin" capturing full context. The route + last
          // client error (ErrorBoundary/window.onerror/unhandledrejection)
          // are already collected by lib/error-reporting; snapshot them onto
          // the ticket so triage starts with what the user saw, not a bare
          // "it's broken". Best-effort: each part is independently guarded.
          context: buildTicketContext(),
        },
      });
      onCreated();
      onClose();
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title="Raise a ticket"
      description="Reach the Praxis team directly — ask for help, report a bug, or request a feature."
    >
      <form className="space-y-4" onSubmit={submit}>
        <Field label={tr("Type")} required>
          <Select
            value={kind}
            onChange={(e) => setKind(e.target.value as Kind)}
          >
            <option value="SUPPORT">Support — I need help</option>
            <option value="BUG">Bug — something’s broken</option>
            <option value="FEATURE">Feature — I’d like an improvement</option>
          </Select>
        </Field>
        <Field label={tr("Summary")} required>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="One line describing it"
            maxLength={200}
          />
        </Field>
        <Field
          label={tr("Details")}
          hint="What happened, what you expected, where in the app (optional)."
        >
          <Textarea
            className="min-h-[110px]"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Add any detail that would help us…"
            maxLength={5000}
          />
        </Field>
        {error && <ErrorState message={error} />}
        <div className="flex justify-end gap-2 pt-2">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={busy}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            loading={busy}
            disabled={title.trim().length < 3 || busy}
          >
            Send to Praxis
          </Button>
        </div>
      </form>
    </Modal>
  );
}

function CsatModal({
  ticket,
  onClose,
  onRated,
}: {
  ticket: Ticket;
  onClose: () => void;
  onRated: () => void;
}) {
  const [score, setScore] = React.useState<number>(5);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await tenant(`/support/tickets/${ticket.ticket_id}/csat`, {
        method: "POST",
        body: { csat: score },
      });
      onRated();
      onClose();
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title="Rate this resolution"
      description={ticket.title}
    >
      <form className="space-y-4" onSubmit={submit}>
        <Field label="How satisfied are you?" required>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setScore(n)}
                className={`h-10 w-10 rounded-md border text-lg transition ${n <= score ? "border-primary bg-primary/10 text-primary-ink" : "border-input text-muted-foreground"}`}
                aria-label={`${n} star${n > 1 ? "s" : ""}`}
              >
                ★
              </button>
            ))}
          </div>
        </Field>
        {error && <ErrorState message={error} />}
        <div className="flex justify-end gap-2 pt-2">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={busy}
          >
            Cancel
          </Button>
          <Button type="submit" loading={busy}>
            Submit rating
          </Button>
        </div>
      </form>
    </Modal>
  );
}

export function SupportPage() {
  const { rows, error, loading, reload } = useList<Ticket>("/support/tickets");
  const [creating, setCreating] = React.useState(false);
  const [rating, setRating] = React.useState<Ticket | null>(null);
  const list = rows || [];

  const open = list.filter((t) => !isResolved(t.status)).length;
  const resolved = list.filter((t) => isResolved(t.status)).length;

  const columns: Column<Ticket>[] = [
    {
      key: "title",
      label: "Ticket",
      render: (r) => (
        <div>
          <div className="font-medium text-foreground">{r.title}</div>
          {r.body ? (
            <div className="micro line-clamp-1 max-w-md text-muted-foreground">
              {r.body}
            </div>
          ) : null}
        </div>
      ),
    },
    {
      key: "kind",
      label: "Type",
      render: (r) => (
        <Pill tone={KIND_TONE[r.kind] || "mute"}>
          {KIND_LABEL[r.kind] || r.kind}
        </Pill>
      ),
    },
    {
      key: "status",
      label: "Status",
      render: (r) => (
        <Pill tone={STATUS_TONE[r.status] || "mute"}>
          {STATUS_LABEL[r.status] || r.status}
        </Pill>
      ),
    },
    {
      key: "created_at",
      label: "Raised",
      render: (r) => dateFmt(r.created_at),
    },
    {
      key: "csat",
      label: "Rating",
      render: (r) => {
        if (r.csat)
          return (
            <span className="num text-primary-ink">
              {"★".repeat(r.csat)}
              <span className="text-muted-foreground">
                {"★".repeat(5 - r.csat)}
              </span>
            </span>
          );
        if (isResolved(r.status))
          return (
            <RowActions>
              <Button size="sm" variant="outline" onClick={() => setRating(r)}>
                Rate
              </Button>
            </RowActions>
          );
        return <span className="text-muted-foreground">—</span>;
      },
    },
  ];

  return (
    <section className={pageShell.wide}>
      <PageHeader
        title="Support & feedback"
        description="Reach the Praxis team directly. Raise a ticket and track it from New through to Shipped."
        action={
          <Button onClick={() => setCreating(true)}>Raise a ticket</Button>
        }
      />
      <KpiRow>
        <KpiTile label="Total tickets" value={num(list.length)} />
        <KpiTile label={tr("Open")} value={num(open)} />
        <KpiTile label="Resolved" value={num(resolved)} />
      </KpiRow>
      <DataList
        columns={columns}
        rows={rows}
        error={error}
        loading={loading}
        rowKey={(r) => r.ticket_id}
        empty={{
          title: "No tickets yet",
          hint: "Raise a ticket to reach the Praxis team — support, a bug, or a feature request.",
        }}
      />
      {creating && (
        <NewTicketModal onClose={() => setCreating(false)} onCreated={reload} />
      )}
      {rating && (
        <CsatModal
          ticket={rating}
          onClose={() => setRating(null)}
          onRated={reload}
        />
      )}
    </section>
  );
}
